package com.example.lab3_a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.lab3_a.entity.Actor;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private List<Actor> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        data = createList();
        ListView list = findViewById(R.id.list);


        ActorAdapter adapter = new ActorAdapter(this, data);


        list.setAdapter(adapter);
        list.setOnItemClickListener(this);
    }

    private List<Actor>  createList(){
        List<Actor> list = new ArrayList<>();

        Actor jimcarrey = new Actor(R.drawable.jimcarrey,"Джим Кери","Комедии",R.string.jim);
        Actor jackiechan = new Actor(R.drawable.jackiechan,"Джеки Чан","Коммедии",R.string.jac);
        Actor margotrobbie = new Actor(R.drawable.margotrobbie,"Марго Робби","Драммы, Фантастика",R.string.margo);
        Actor affleck = new Actor(R.drawable.affleck,"Бен Афлек","Экшн, драммы",R.string.afl);
        Actor tobeymaguire  = new Actor(R.drawable.tobeymaguire,"Тобби Магуаер","Фантастика, фэнтэзи",R.string.tobie);
        Actor robertdowneyjr = new Actor(R.drawable.robertdowneyjr,"Роберт Дауни Младший","Драммы, фантастика",R.string.robert);

        list.add(jimcarrey);
        list.add(jackiechan);
        list.add(margotrobbie);
        list.add(affleck);
        list.add(tobeymaguire);
        list.add(robertdowneyjr);

        return list;
    }
//открытие новой вкладки при клике на элемент списка
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this,ActorActivity.class);
        intent.putExtra("Actor",data.get(position));
        startActivity(intent);
    }
}
