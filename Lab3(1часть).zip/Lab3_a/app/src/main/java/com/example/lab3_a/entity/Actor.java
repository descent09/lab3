package com.example.lab3_a.entity;

import java.io.Serializable;

public class Actor implements Serializable {
    private int image;
    private String name;
    private String genres;
    private int description;

    public Actor(int image, String name, String genres, int description) {
        this.image = image;
        this.name = name;
        this.genres = genres;
        this.description = description;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }

    public String getGenres(){
        return genres;
    }

    public void setGenres(String genres) {
        this.genres = genres;
    }
    /* public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGenres() {
        return genres;
    }

    public void setGenres(String genres) {
        this.genres = genres;
    }*/

    public int getDescription() {
        return description;
    }

    public void setDescription(int description) {
        this.description = description;
    }
}
