package com.example.lab3_a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lab3_a.entity.Actor;


import java.util.List;

public class ActorAdapter  extends BaseAdapter {

    private List<Actor> data;
    private LayoutInflater inflater;
    public ActorAdapter(Context context, List<Actor> data){
    //public ActorAdapter(Context context, List<Actor> data) {
        this.data = data;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null)
            convertView = inflater.inflate(R.layout.list_item, parent, false);

        // 2. Получаем доступ к виджетам дерева объектов
        TextView name = convertView.findViewById(R.id.actor_name);
        TextView genres = convertView.findViewById(R.id.actor_genres);
        ImageView image = convertView.findViewById(R.id.image_actor);

        // 3. Меняем содержимое виджетов
        name.setText(data.get(position).getName());
        genres.setText(data.get(position).getGenres());
        image.setImageResource(data.get(position).getImage());
        // 4. Возвращаем модифицированное дерево объектов
        return convertView;
    }
}