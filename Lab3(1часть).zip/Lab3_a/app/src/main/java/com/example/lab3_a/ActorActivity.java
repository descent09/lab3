package com.example.lab3_a;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lab3_a.entity.Actor;


public class ActorActivity extends AppCompatActivity implements View.OnClickListener {

    private Button back;
    private TextView name;
    private TextView genres;
    private TextView description;
    private ImageView image;

    private Actor actor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actor_description_layout);

        back = findViewById(R.id.back);
        name = findViewById(R.id.actor_name);
        genres = findViewById(R.id.actor_genres);
        description = findViewById(R.id.actor_description);
        image = findViewById(R.id.actor_image);

        back.setOnClickListener(this);

        actor = (Actor) getIntent().getSerializableExtra("Actor");
        name.setText(actor.getName());
        genres.setText(actor.getGenres());
        description.setText(actor.getDescription());
        image.setImageResource(actor.getImage());
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}