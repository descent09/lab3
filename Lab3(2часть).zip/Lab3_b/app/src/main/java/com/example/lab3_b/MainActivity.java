package com.example.lab3_b;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab3_b.entity.Animal;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  {
    // массив животных
    private List<Animal> data;
    private RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         data = createList();

        // Создаем объект адаптера
        rv = findViewById(R.id.list);
        rv.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rv.setLayoutManager(layoutManager);
        //подключили адаптер
        rv.setAdapter(new AnimalAdapter(data, this));
        //добавили действие при клике на элемент
        rv.addOnItemTouchListener(
                new RecyclerItemClickListener(this, rv ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        Intent intent = new Intent(getLayoutInflater().getContext(),AnimalActivity.class);
                        intent.putExtra("Animal",data.get(position));
                        startActivity(intent);
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );
    }
    //создание массива животных
    private List<Animal>  createList(){
        List<Animal> list = new ArrayList<>();

        Animal elephant = new Animal(R.drawable.jimcarrey,"Джим Кери","Комедии",R.string.elephant);
        Animal hippopotamus = new Animal(R.drawable.jackiechan,"Джеки Чан","Комедии",R.string.hippopotamus);
        Animal eagle = new Animal(R.drawable.margotrobbie,"Марго Робби","Драммы",R.string.eagle);
        Animal ladybug = new Animal(R.drawable.affleck,"Бен Афлек","Экшн, драммы",R.string.ladybug);
        Animal shark = new Animal(R.drawable.tobeymaguire,"Тобби Магуаер","Фантастика, фэнтэзи",R.string.shark);
        Animal sturgeon = new Animal(R.drawable.robertdowneyjr,"Роберт Дауни Младший","Драммы, фантастика",R.string.sturgeon);

        list.add(sturgeon);
        list.add(shark);
        list.add(ladybug);
        list.add(elephant);
        list.add(eagle);
        list.add(hippopotamus);

        return list;
    }

}
